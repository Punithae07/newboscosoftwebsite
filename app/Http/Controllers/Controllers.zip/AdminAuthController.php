<?php

namespace App\Http\Controllers;

use App\Http\Requests\Admin\AdminChangePasswordRequest;
use App\Http\Requests\Admin\AdminLoginRequest;
use App\Models\AdminUser;
use App\Services\AdminUserRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AdminAuthController
{
    public function __construct(private readonly AdminUserRepository $adminUsers)
    {
    }

    public function login(AdminLoginRequest $request): JsonResponse
    {
        $validated = $request->validated();
        $incomingEmail = Str::lower(trim($validated['email']));
        $incomingPassword = $validated['password'];

        $adminUser = $this->adminUsers->findActiveByEmail($incomingEmail);

        if ($adminUser instanceof AdminUser) {
            if (! Hash::check($incomingPassword, (string) $adminUser->password)) {
                return response()->json([
                    'message' => 'Invalid credentials.',
                ], 422);
            }

            $adminUser->forceFill([
                'last_login_at' => now(),
            ])->save();

            return $this->createAuthenticatedSession($request, $adminUser->id, (string) $adminUser->email, (string) $adminUser->name);
        }

        return $this->attemptLegacyEnvLogin($request, $incomingEmail, $incomingPassword);
    }

    public function changePassword(AdminChangePasswordRequest $request): JsonResponse
    {
        $validated = $request->validated();
        $email = Str::lower(trim($validated['email']));
        $adminUser = $this->adminUsers->findActiveByEmail($email);

        if (! $adminUser instanceof AdminUser) {
            return response()->json([
                'message' => 'This admin account was not found in the database.',
            ], 404);
        }

        if (! Hash::check($validated['current_password'], (string) $adminUser->password)) {
            return response()->json([
                'message' => 'Current password is incorrect.',
            ], 422);
        }

        if (Hash::check($validated['new_password'], (string) $adminUser->password)) {
            return response()->json([
                'message' => 'Choose a different password from your current one.',
            ], 422);
        }

        $adminUser->forceFill([
            'password' => Hash::make($validated['new_password']),
        ])->save();

        return response()->json([
            'message' => 'Password changed successfully. Please sign in with your new password.',
        ]);
    }

    public function session(Request $request): JsonResponse
    {
        return response()->json([
            'session' => [
                'id' => $request->session()->get('admin_user_id'),
                'name' => (string) $request->session()->get('admin_name', ''),
                'email' => (string) $request->session()->get('admin_email'),
                'expires_in_minutes' => (int) config('admin.session_lifetime', 120),
            ],
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json([
            'message' => 'Logged out successfully.',
        ]);
    }

    private function attemptLegacyEnvLogin(Request $request, string $incomingEmail, string $incomingPassword): JsonResponse
    {
        $email = Str::lower(trim((string) config('admin.email', '')));
        $passwordHash = (string) config('admin.password_hash', '');
        $plainPassword = (string) config('admin.password', '');

        if ($email === '' || ($passwordHash === '' && $plainPassword === '')) {
            return response()->json([
                'message' => 'Admin login is not configured.',
            ], 503);
        }

        $validPassword = $passwordHash !== ''
            ? Hash::check($incomingPassword, $passwordHash)
            : (app()->environment('local') && hash_equals($plainPassword, $incomingPassword));

        if (! hash_equals($email, $incomingEmail) || ! $validPassword) {
            return response()->json([
                'message' => 'Invalid credentials.',
            ], 422);
        }

        return $this->createAuthenticatedSession($request, null, $email, 'Primary Admin');
    }

    private function createAuthenticatedSession(Request $request, ?int $adminUserId, string $email, string $name): JsonResponse
    {
        $request->session()->invalidate();
        $request->session()->regenerate();
        $request->session()->put([
            'admin_authenticated' => true,
            'admin_user_id' => $adminUserId,
            'admin_name' => $name,
            'admin_email' => $email,
            'admin_last_activity' => time(),
        ]);

        return response()->json([
            'session' => [
                'id' => $adminUserId,
                'name' => $name,
                'email' => $email,
                'expires_in_minutes' => (int) config('admin.session_lifetime', 120),
            ],
        ]);
    }
}
